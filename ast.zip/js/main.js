
$('.main__nums').addClass('animate');

var swiper = new Swiper(".places .swiper", {
    slidesPerView: 'auto',
    loop: true,
    spaceBetween: 124,
    centeredSlides: true,
    navigation: {
        nextEl: '.places__next',
        prevEl: '.places__prev',
    },
    pagination: {
        el: ".places .swiper-pagination",
        clickable: true,
    },
});

var swiper2 = new Swiper(".pent .swiper", {
    slidesPerView: 'auto',
    loop: true,
    spaceBetween: 124,
    centeredSlides: true,
    navigation: {
        nextEl: '.pent__next',
        prevEl: '.pent__prev',
    },
    pagination: {
        el: ".pent .swiper-pagination",
        clickable: true,
    },
});
var swiper3 = new Swiper(".serv__all", {
    slidesPerView: 1,
    loop: true,
    spaceBetween: 0,
    navigation: {
        nextEl: '.serv__next',
        prevEl: '.serv__prev',
    },
    pagination: {
        el: ".serv__nav .swiper-pagination",
        clickable: true,
    },
});
var swiper4 = new Swiper(".inzh .swiper", {
    slidesPerView: 1,
    loop: true,
    spaceBetween: 0,
    navigation: {
        nextEl: '.inzh__next',
        prevEl: '.inzh__prev',
    },
});
$("body").on('click', '[href*="#"]', function (e) {
    var fixed_offset = 132;
    $('html,body').stop().animate({ scrollTop: $(this.hash).offset().top - fixed_offset }, 1000);
    e.preventDefault();
});
$('.menu a').on('click', function () {
    $('.menu').removeClass('active');
    $('.menu-close').removeClass('active');
});
$('.header__burg').on('click', function (e) {
    e.preventDefault();
    $('.menu').toggleClass('active');
    $('.menu-close').toggleClass('active');
});
$('.menu-close').on('click', function (e) {
    e.preventDefault();
    $('.menu').removeClass('active');
    $('.menu-close').removeClass('active');
});